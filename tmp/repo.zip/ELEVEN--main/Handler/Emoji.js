module.exports = {
    tick: '<:tick:1365995106645053580> ',
    cross: '<:crosss:1144288980385415279>',
    delete: '<:delete:1274950067421184054>',
};